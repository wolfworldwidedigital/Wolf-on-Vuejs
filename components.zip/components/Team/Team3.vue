<template>
  <section id="team" class="team section-padding">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10">
          <div class="sec-head text-center">
            <h2 class="wow fadeIn" data-wow-delay=".3s">Our Team</h2>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-lg-4">
          <div class="item cir md-mb50">
            <div class="img">
              <img src="/img/team/a1.jpg" alt="" />
              <div id="circle">
                <svg version="1.1" x="0px" y="0px" width="300px" height="300px" viewBox="0 0 300 300"
                  enableBackground="new 0 0 300 300" xmlSpace="preserve">
                  <defs>
                    <path id="circlePath" d=" M 150, 150 m -60, 0 a 60,60 0 0,1 120,0 a 60,60 0 0,1 -120,0 " />
                  </defs>
                  <circle cx="150" cy="100" r="75" fill="none" />
                  <g>
                    <use xlink:href="#circlePath" fill="none" />
                    <text fill="#c5a47e" class="custom-font">
                      <textPath xlink:href="#circlePath">
                        CEO Manager - CEO Manager - CEO Manager -
                      </textPath>
                    </text>
                  </g>
                </svg>
              </div>
              <div class="info">
                <h6 class="ls3">Ryan Hicks</h6>
                <span class="main-color fw-600">Client Manager</span>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="item cir md-mb50">
            <div class="img">
              <img src="/img/team/a2.jpg" alt="" />
              <div id="circle">
                <svg version="1.1" x="0px" y="0px" width="300px" height="300px" viewBox="0 0 300 300"
                  enableBackground="new 0 0 300 300" xmlSpace="preserve">
                  <defs>
                    <path id="circlePath" d=" M 150, 150 m -60, 0 a 60,60 0 0,1 120,0 a 60,60 0 0,1 -120,0 " />
                  </defs>
                  <circle cx="150" cy="100" r="75" fill="none" />
                  <g>
                    <use xlink:href="#circlePath" fill="none" />
                    <text fill="#c5a47e" class="custom-font">
                      <textPath xlink:href="#circlePath">
                        Interior Designer Interior Designer Interior Designer
                      </textPath>
                    </text>
                  </g>
                </svg>
              </div>
              <div class="info">
                <h6 class="ls3">Ryan Hicks</h6>
                <span class="main-color fw-600">Client Manager</span>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="item cir sm-mb50">
            <div class="img">
              <img src="/img/team/a3.jpg" alt="" />
              <div id="circle">
                <svg version="1.1" x="0px" y="0px" width="300px" height="300px" viewBox="0 0 300 300"
                  enableBackground="new 0 0 300 300" xmlSpace="preserve">
                  <defs>
                    <path id="circlePath" d=" M 150, 150 m -60, 0 a 60,60 0 0,1 120,0 a 60,60 0 0,1 -120,0 " />
                  </defs>
                  <circle cx="150" cy="100" r="75" fill="none" />
                  <g>
                    <use xlink:href="#circlePath" fill="none" />
                    <text fill="#c5a47e" class="custom-font">
                      <textPath xlink:href="#circlePath">
                        Landscape Designer Landscape Designer Landscape Designer
                      </textPath>
                    </text>
                  </g>
                </svg>
              </div>
              <div class="info">
                <h6 class="ls3">Ryan Hicks</h6>
                <span class="main-color fw-600">Client Manager</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>