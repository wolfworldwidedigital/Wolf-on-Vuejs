<template>
  <section class="services section-padding position-re">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10">
          <div class="sec-head text-center">
            <h6 class="wow fadeIn" data-wow-delay=".5s">Best Features</h6>
            <h3 class="wow color-font">
              We are a new digital product development agency
            </h3>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-4 wow fadeInUp" data-wow-delay=".3s">
          <div class="step-item xtop">
            <span class="icon pe-7s-gleam"></span>
            <h6>Digital Marketing</h6>
            <p>
              Tempore corrupti temporibus fuga earum asperiores fugit
              laudantium.
            </p>
          </div>
        </div>
        <div class="col-lg-4 wow fadeInUp" data-wow-delay=".6s">
          <div class="step-item xcolor">
            <span class="icon pe-7s-phone"></span>
            <h6>Web &amp; App Development</h6>
            <p>
              Tempore corrupti temporibus fuga earum asperiores fugit
              laudantium.
            </p>
          </div>
        </div>
        <div class="col-lg-4 wow fadeInUp" data-wow-delay=".9s">
          <div class="step-item xbottom">
            <span class="icon pe-7s-magic-wand"></span>
            <h6>Graphic Design</h6>
            <p>
              Tempore corrupti temporibus fuga earum asperiores fugit
              laudantium.
            </p>
          </div>
        </div>
      </div>
      <div class="smore">
        <NuxtLink to="#0">Discover More</NuxtLink>
        <i class="fas fa-long-arrow-alt-right"></i>
      </div>
    </div>
    <div class="line top left"></div>
    <div class="line bottom right"></div>
  </section>
</template>