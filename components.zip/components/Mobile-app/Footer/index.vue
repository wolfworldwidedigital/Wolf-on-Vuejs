<template>
  <footer class="app-footer" data-overlay-dark="0">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-6">
          <div class="item-clumn our md-mb50">
            <a href="#0" class="logo-brand mb-50">
              <img src="/img/logo-gr.png" alt="">
            </a>
            <p>Sed ut perspiciatis undmnis iste natus error sit voluptatem accusantium dolore udantiuy totam rem aperiam.
            </p>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="item-clumn links md-mb50">
            <h5 class="title">Resources</h5>
            <ul>
              <li><span class="icon pe-7s-angle-right"></span><a href="#0">Our Products</a> </li>
              <li><span class="icon pe-7s-angle-right"></span><a href="#0">Blogs & Guides</a></li>
              <li><span class="icon pe-7s-angle-right"></span><a href="#0">Premium Support</a> </li>
              <li><span class="icon pe-7s-angle-right"></span><a href="#0">Need a Career ?</a> </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-2 col-md-6">
          <div class="item-clumn links sm-mb50">
            <h5 class="title">Links</h5>
            <ul>
              <li><span class="icon pe-7s-angle-right"></span><a href="#0">Support</a> </li>
              <li><span class="icon pe-7s-angle-right"></span><a href="#0">Privacy</a> </li>
              <li><span class="icon pe-7s-angle-right"></span><a href="#0">Setting</a> </li>
              <li><span class="icon pe-7s-angle-right"></span><a href="#0">My Account</a> </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="item-clumn links">
            <h5 class="title mb-30">Contact</h5>
            <div class="info">
              <span>Email Address</span>
              <h6><a href="#0">support@gmail.com</a></h6>
            </div>
            <div class="social mt-30">
              <a href="#0"><i class="fab fa-facebook-f"></i></a>
              <a href="#0"><i class="fab fa-twitter"></i></a>
              <a href="#0"><i class="fab fa-instagram"></i></a>
              <a href="#0"><i class="fab fa-youtube"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="sub-footer">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="text-center">
              <p>© 2023 Vie. All Rights Reserved</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="circle-blur"></div>
    <div class="circle-blur two"></div>
  </footer>
</template>