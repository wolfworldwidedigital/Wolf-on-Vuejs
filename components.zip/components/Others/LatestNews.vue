<template>
  <section class="blog section-padding" id="blogs">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10">
          <div class="sec-head text-center">
            <h2 class="wow fadeIn" data-wow-delay=".3s">Latest News</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-6">
          <div class="item md-mb50 wow fadeInUp" data-wow-delay=".3s">
            <div class="img">
              <img src="/img/arch/blog/1.jpg" alt="" />
            </div>
            <div class="cont">
              <div>
                <div class="info">
                  <a href="#0" class="date">
                    <span> <i>06</i> August </span>
                  </a>
                  <span>/</span>
                  <a href="#0" class="tag">
                    <span class="main-color">Architecture</span>
                  </a>
                </div>
                <h5>
                  <a href="#0">
                    How to use solid color combine with simple furnitures.
                  </a>
                </h5>
                <div class="btn-more">
                  <a href="#0" class="simple-btn main-color"> Read More </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="item md-mb50 wow fadeInUp" data-wow-delay=".5s">
            <div class="img">
              <img src="/img/arch/blog/2.jpg" alt="" />
            </div>
            <div class="cont">
              <div>
                <div class="info">
                  <a href="#0" class="date">
                    <span> <i>06</i> August </span>
                  </a>
                  <span>/</span>
                  <a href="#0" class="tag">
                    <span class="main-color">Architecture</span>
                  </a>
                </div>
                <h5>
                  <a href="#0">
                    How to use solid color combine with simple furnitures.
                  </a>
                </h5>
                <div class="btn-more">
                  <a href="#0" class="simple-btn main-color"> Read More </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>