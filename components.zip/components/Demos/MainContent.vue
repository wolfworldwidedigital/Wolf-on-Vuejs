<template>
  <div class="main-content section-padding pb-0">
    <Pages />
    <Showcases />
    <Services />
    <CallToAction />
  </div>
</template>

<script setup>
import initIsotope from "@/common/initIsotope";
//= Components
import Pages from './Pages.vue';
import Showcases from './Showcases.vue';
import Services from './Services.vue';
import CallToAction from './CallToAction.vue';

onMounted(() => {
  setTimeout(() => {
    initIsotope();
  }, 500);
});
</script>

<style scoped>
.sec-head h3 {
  font-size: 60px;
  font-weight: 700;
  position: relative;
}

.sec-head .tbg {
  position: absolute;
  top: -120px;
  left: 0;
  width: 100%;
  font-size: 15vw;
  font-weight: 900;
  line-height: 1;
  background: linear-gradient(180deg, #fff 0%, rgba(17, 18, 21, 0.2) 70%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  opacity: 0.1;
}

.sec-head .tbg b {
  font-weight: 500;
  font-size: 12vw;
}

.main-content {
  position: relative;
  z-index: 999999;
  background: transparent;
}

.masonery .gallery .items {
  margin-top: 30px;
}

.masonery .container-fluid {
  padding: 0 100px;
}

.masonery .item-img {
  padding: 5px 15px 20px;
  border-radius: 10px;
  background: #18191d;
  position: relative;
}

.masonery .item-img .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.05);
}

.masonery .item-img .img {
  border-radius: 10px;
  overflow: hidden;
}

.masonery .item-img .img img {
  transition: all 0.4s;
}

.masonery .item-img .img:hover img {
  transform: scale(1.1);
}

.masonery .item-img .cont {
  margin-top: 20px;
  text-align: center;
  position: relative;
}

.masonery .item-img .cont h6 {
  font-size: 16px;
  font-weight: 500;
  letter-spacing: 1px;
}

.masonery .item-img .cont .sta {
  position: absolute;
  top: -47px;
  left: 50%;
  transform: translateX(-50%);
  padding: 5px 10px;
  border-radius: 30px;
  box-shadow: 0px 5px 20px rgba(255, 255, 255, 0.05);
  font-size: 12px;
}

.masonery .item-img .cont .sta.coming {
  background: #03be5f;
}

.masonery .item-img .cont .sta.new {
  background: #ff4b4b;
}
</style>