<template>
  <section class="masonery section-padding">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10">
          <div class="sec-head text-center">
            <h3 class="color-font">49+ stunning unique ready template</h3>
            <span class="tbg"> <b>+</b>49 </span>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid">
      <div class="row">
        <div class="gallery full-width">
          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/homepage/home1-dark">
                <div class="img">
                  <img src="/demo-img/1.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Main Demo</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/homepage/home1-light">
                <div class="img">
                  <img src="/demo-img/01.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Main Demo</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/homepage/home2-dark">
                <div class="img">
                  <img src="/demo-img/2.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Creative Agency</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/homepage/home2-light">
                <div class="img">
                  <img src="/demo-img/02.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Creative Agency</h6>
                </div>
              </NuxtLink>
            </div>
          </div>
        </div>

        <div class="gallery full-width">

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/mobile-app/mobile-app-dark">
                <div class="img">
                  <img src="/demo-img/mobile1.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Mobile app</h6>
                  <div class="sta new">
                    <span>New Demo</span>
                  </div>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/mobile-app/mobile-app-light">
                <div class="img">
                  <img src="/demo-img/mobile2.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Mobile app</h6>
                  <div class="sta new">
                    <span>New Demo</span>
                  </div>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/homepage/home7-dark">
                <div class="img">
                  <img src="/demo-img/n2.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Freelancer</h6>
                  <!-- <div class="sta new">
                        <span>New Demo</span>
                      </div> -->
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/homepage/home7-light">
                <div class="img">
                  <img src="/demo-img/n02.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Freelancer</h6>
                </div>
              </NuxtLink>
            </div>
          </div>
        </div>

        <div class="gallery full-width">
          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/homepage/home8-dark">
                <div class="img">
                  <img src="/demo-img/n3.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Architecture</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/homepage/home8-light">
                <div class="img">
                  <img src="/demo-img/n03.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Architecture</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/homepage/home5-dark">
                <div class="img">
                  <img src="/demo-img/3.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Digital Agency</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/homepage/home5-light">
                <div class="img">
                  <img src="/demo-img/03.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Digital Agency</h6>
                </div>
              </NuxtLink>
            </div>
          </div>
        </div>

        <div class="gallery full-width">
          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/homepage/home3-dark">
                <div class="img">
                  <img src="/demo-img/5.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Corporate Business</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/homepage/home3-light">
                <div class="img">
                  <img src="/demo-img/05.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Corporate Business</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/homepage/home6-dark">
                <div class="img">
                  <img src="/demo-img/n1.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Modern Agency</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/homepage/home6-light">
                <div class="img">
                  <img src="/demo-img/n01.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Modern Agency</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/homepage/home4-dark">
                <div class="img">
                  <img src="/demo-img/4.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Business One Page</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/homepage/home4-light">
                <div class="img">
                  <img src="/demo-img/04.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Business One Page</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <div class="img">
                <img src="/demo-img/c3.png" alt="image" />
              </div>
              <div class="cont">
                <h6>Restaurant</h6>
                <div class="sta coming">
                  <span>Coming Soon</span>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <div class="img">
                <img src="/demo-img/c4.png" alt="image" />
              </div>
              <div class="cont">
                <h6>Multipurpose</h6>
                <div class="sta coming">
                  <span>Coming Soon</span>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>
</template>


<style scoped>
.sec-head h3 {
  font-size: 60px;
  font-weight: 700;
  position: relative;
}

.sec-head .tbg {
  position: absolute;
  top: -120px;
  left: 0;
  width: 100%;
  font-size: 15vw;
  font-weight: 900;
  line-height: 1;
  background: linear-gradient(180deg, #fff 0%, rgba(17, 18, 21, 0.2) 70%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  opacity: 0.1;
}

.sec-head .tbg b {
  font-weight: 500;
  font-size: 12vw;
}

.main-content {
  position: relative;
  z-index: 999999;
  background: transparent;
}

.masonery .gallery .items {
  margin-top: 30px;
}

.masonery .container-fluid {
  padding: 0 100px;
}

.masonery .item-img {
  padding: 5px 15px 20px;
  border-radius: 10px;
  background: #18191d;
  position: relative;
}

.masonery .item-img .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.05);
}

.masonery .item-img .img {
  border-radius: 10px;
  overflow: hidden;
}

.masonery .item-img .img img {
  transition: all 0.4s;
}

.masonery .item-img .img:hover img {
  transform: scale(1.1);
}

.masonery .item-img .cont {
  margin-top: 20px;
  text-align: center;
  position: relative;
}

.masonery .item-img .cont h6 {
  font-size: 16px;
  font-weight: 500;
  letter-spacing: 1px;
}

.masonery .item-img .cont .sta {
  position: absolute;
  top: -47px;
  left: 50%;
  transform: translateX(-50%);
  padding: 5px 10px;
  border-radius: 30px;
  box-shadow: 0px 5px 20px rgba(255, 255, 255, 0.05);
  font-size: 12px;
}

.masonery .item-img .cont .sta.coming {
  background: #03be5f;
}

.masonery .item-img .cont .sta.new {
  background: #ff4b4b;
}
</style>