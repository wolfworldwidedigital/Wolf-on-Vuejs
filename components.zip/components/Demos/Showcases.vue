<template>
  <section class="masonery section-padding position-re">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10">
          <div class="sec-head text-center">
            <h3 class="color-font">Showcases</h3>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid">
      <div class="row">
        <div class="gallery full-width">
          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/showcase/showcase-dark">
                <div class="img">
                  <img src="/demo-img/s1.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Full Screen</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/showcase/showcase-light">
                <div class="img">
                  <img src="/demo-img/s01.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Full Screen</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/showcase3/showcase3-dark">
                <div class="img">
                  <img src="/demo-img/s2.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Showcase Carousel</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/showcase3/showcase3-light">
                <div class="img">
                  <img src="/demo-img/s02.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Showcase Carousel</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/showcase2/showcase2-dark">
                <div class="img">
                  <img src="/demo-img/s3.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Showcase Circle</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/showcase2/showcase2-light">
                <div class="img">
                  <img src="/demo-img/s03.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Showcase Circle</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/works/works-dark">
                <div class="img">
                  <img src="/demo-img/w1.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Works 3 column</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/works/works-light">
                <div class="img">
                  <img src="/demo-img/w01.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Works 3 column</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/works2/works2-dark">
                <div class="img">
                  <img src="/demo-img/w2.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Works Filtering</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/works2/works2-light">
                <div class="img">
                  <img src="/demo-img/w02.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Works Filtering</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/works3/works3-dark">
                <div class="img">
                  <img src="/demo-img/w3.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Works Gallery</h6>
                </div>
              </NuxtLink>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 items">
            <div class="item-img wow fadeInUp" data-wow-delay=".4s">
              <span class="dot"></span>
              <span class="dot"></span>
              <span class="dot"></span>
              <NuxtLink target="_blank" to="/works3/works3-light">
                <div class="img">
                  <img src="/demo-img/w03.png" alt="image" />
                </div>
                <div class="cont">
                  <h6>Works Gallery</h6>
                </div>
              </NuxtLink>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="line top left"></div>
  </section>
</template>

<style scoped>
.sec-head h3 {
  font-size: 60px;
  font-weight: 700;
  position: relative;
}

.sec-head .tbg {
  position: absolute;
  top: -120px;
  left: 0;
  width: 100%;
  font-size: 15vw;
  font-weight: 900;
  line-height: 1;
  background: linear-gradient(180deg, #fff 0%, rgba(17, 18, 21, 0.2) 70%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  opacity: 0.1;
}

.sec-head .tbg b {
  font-weight: 500;
  font-size: 12vw;
}

.main-content {
  position: relative;
  z-index: 999999;
  background: transparent;
}

.masonery .gallery .items {
  margin-top: 30px;
}

.masonery .container-fluid {
  padding: 0 100px;
}

.masonery .item-img {
  padding: 5px 15px 20px;
  border-radius: 10px;
  background: #18191d;
  position: relative;
}

.masonery .item-img .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.05);
}

.masonery .item-img .img {
  border-radius: 10px;
  overflow: hidden;
}

.masonery .item-img .img img {
  transition: all 0.4s;
}

.masonery .item-img .img:hover img {
  transform: scale(1.1);
}

.masonery .item-img .cont {
  margin-top: 20px;
  text-align: center;
  position: relative;
}

.masonery .item-img .cont h6 {
  font-size: 16px;
  font-weight: 500;
  letter-spacing: 1px;
}

.masonery .item-img .cont .sta {
  position: absolute;
  top: -47px;
  left: 50%;
  transform: translateX(-50%);
  padding: 5px 10px;
  border-radius: 30px;
  box-shadow: 0px 5px 20px rgba(255, 255, 255, 0.05);
  font-size: 12px;
}

.masonery .item-img .cont .sta.coming {
  background: #03be5f;
}

.masonery .item-img .cont .sta.new {
  background: #ff4b4b;
}
</style>