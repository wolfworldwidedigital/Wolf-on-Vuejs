<template>
  <section id="about" class="about-ar section-padding">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 valign">
          <div class="img">
            <div class="bg-img bg-fixed hero-bg" style="background-image: url(/img/arch/hero.jpg)"></div>
            <div class="exp valign text-center">
              <div class="full-width">
                <h2 class="bg-img bg-fixed" style="background-image: url(/img/arch/hero.jpg)">
                  25
                </h2>
                <p>Years Of Experience</p>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-6 valign">
          <div class="content">
            <h6 class="sub-title main-color ls10 text-u">About Us</h6>
            <h3>Best Designers Architectures for You.</h3>
            <p>
              Architecture bibendum pharetra eleifend. Suspendisse vel volutpat
              purus, sit amet bibendum nisl. Cras mollis turpis a ipsum ultes,
              nec condimentum ipsum consequat. Mauris vitae consequat nibh,
              vitae interdum sit amet bibendum nisl.
            </p>

            <NuxtLink class="butn bord mt-30" to="/about/about-dark">
              <span>About Us</span>
            </NuxtLink>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>