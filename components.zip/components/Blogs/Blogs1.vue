<template>
  <section class="blog section-padding sub-bg">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10">
          <div class="sec-head text-center">
            <h6 class="wow fadeIn" data-wow-delay=".5s">RECENT ARTICLES</h6>
            <h3 class="wow color-font">From our blogs.</h3>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-6">
          <div class="item md-mb50 wow fadeInUp" data-wow-delay=".3s">
            <div class="img">
              <img src="/img/blog/1.jpg" alt="" />
            </div>
            <div class="cont">
              <div>
                <div class="info">
                  <NuxtLink to="#" class="date">
                    <span> <i>06</i> August </span>
                  </NuxtLink>
                  <span>/</span>
                  <NuxtLink to="#" class="tag">
                    <span>WordPress</span>
                  </NuxtLink>
                </div>
                <h5>
                  <NuxtLink to="#">
                    How to use solid color combine with simple furnitures.
                  </NuxtLink>
                </h5>
                <div class="btn-more">
                  <NuxtLink to="#" class="simple-btn"> Read More </NuxtLink>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="item md-mb50 wow fadeInUp" data-wow-delay=".5s">
            <div class="img">
              <img src="/img/blog/2.jpg" alt="" />
            </div>
            <div class="cont">
              <div>
                <div class="info">
                  <NuxtLink to="#" class="date">
                    <span> <i>06</i> August </span>
                  </NuxtLink>
                  <span>/</span>
                  <NuxtLink to="#" class="tag">
                    <span>WordPress</span>
                  </NuxtLink>
                </div>
                <h5>
                  <NuxtLink to="#">
                    How to use solid color combine with simple furnitures.
                  </NuxtLink>
                </h5>
                <div class="btn-more">
                  <NuxtLink to="#" class="simple-btn"> Read More </NuxtLink>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>