<template>
  <section class="blog-grid section-padding position-re">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10">
          <div class="sec-head text-center">
            <h6 class="wow fadeIn" data-wow-delay=".5s">RECENT ARTICLES</h6>
            <h3 class="wow color-font">From our blogs.</h3>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-4 wow fadeInUp" data-wow-delay=".3s">
          <div class="item bg-img" style="background-image: url('/img/blog/1.jpg')">
            <div class="cont">
              <NuxtLink to="#0" class="date">
                <span> <i>06</i> Aug 2023 </span>
              </NuxtLink>
              <div class="info">
                <NuxtLink to="#0" class="author">
                  <span>by / Admin</span>
                </NuxtLink>
                <NuxtLink to="#0" class="tag">
                  <span>WordPress</span>
                </NuxtLink>
              </div>
              <h6>
                <NuxtLink to="#0">
                  The Start-Up Ultimate Guide to Make Your WordPress Journal.
                </NuxtLink>
              </h6>
              <div class="btn-more">
                <NuxtLink to="#0" class="simple-btn"> Read More </NuxtLink>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 wow fadeInUp" data-wow-delay=".6s">
          <div class="item active bg-img" style="background-image: url('/img/blog/2.jpg')">
            <div class="cont">
              <NuxtLink to="#0" class="date">
                <span> <i>06</i> Aug 2023 </span>
              </NuxtLink>
              <div class="info">
                <NuxtLink to="#0" class="author">
                  <span>by / Admin</span>
                </NuxtLink>
                <NuxtLink to="#0" class="tag">
                  <span>WordPress</span>
                </NuxtLink>
              </div>
              <h6>
                <NuxtLink to="#0">
                  The Start-Up Ultimate Guide to Make Your WordPress Journal.
                </NuxtLink>
              </h6>
              <div class="btn-more">
                <NuxtLink to="#0" class="simple-btn"> Read More </NuxtLink>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 wow fadeInUp" data-wow-delay=".9s">
          <div class="item bg-img" style="background-image: url('/img/blog/3.jpg')">
            <div class="cont">
              <NuxtLink to="#0" class="date">
                <span> <i>06</i> Aug 2023 </span>
              </NuxtLink>
              <div class="info">
                <NuxtLink to="#0" class="author">
                  <span>by / Admin</span>
                </NuxtLink>
                <NuxtLink to="#0" class="tag">
                  <span>WordPress</span>
                </NuxtLink>
              </div>
              <h6>
                <NuxtLink to="#0">
                  The Start-Up Ultimate Guide to Make Your WordPress Journal.
                </NuxtLink>
              </h6>
              <div class="btn-more">
                <NuxtLink to="#0" class="simple-btn"> Read More </NuxtLink>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="line top right"></div>
    <div class="line bottom left"></div>
  </section>
</template>
