<template>
  <div class="pagination">
    <span>
      <a href="#0">Prev Post</a>
    </span>
    <span class="icon">
      <NuxtLink to="/blog/blog-dark">
        <i class="fas fa-th-large"></i>
      </NuxtLink>
    </span>
    <span class="text-right">
      <a href="#0">Next Post</a>
    </span>
  </div>
</template>