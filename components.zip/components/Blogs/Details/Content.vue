<template>
  <div class="content pt-60">
    <div class="row justify-content-center">
      <div class="col-lg-10">
        <div class="cont">
          <h4 class="extra-title">
            Priorities that will pop up in any particular month.
          </h4>
          <div class="spacial">
            <p>
              Never ever think of giving up. Winners never quit and
              quitters never win. Take all negative words out of your
              mental dictionary and focus on the solutions with utmost
              conviction and patience. The battle is never lost until
              you've abandon your vision.
            </p>
          </div>
          <p>
            the main component of a healthy environment for self
            esteem is that it needs be nurturing. The main compont of
            a healthy environment for self esteem is that it needs be
            nurturing. The main component of a healthy env for self
            esteem The main compont be nurturing It should provide
            unconditional warmth. The main component of a healthy env
            for self esteem The main compont be nurturing It should
            provide unconditional
          </p>

          <h6>- We all intend to plan ahead.</h6>

          <p>
            We all intend to plan ahead, but too often let the
            day-to-day minutia get in the way of making a calendar for
            the year. Sure, you can't know every detail to anticipate.
            Heck, you can't know half the priorities that will pop up
            in any particular month. But you can plan for big picture
            seasonality, busy-times, and events.
          </p>

          <ul>
            <li><span>01</span> Integer in volutpat libero.</li>
            <li>
              <span>02</span> Vivamus maximus ultricies pulvinar.
            </li>
            <li>
              <span>03</span> priorities that will pop up in any
              particular month.
            </li>
            <li><span>04</span> We all intend to plan ahead.</li>
            <li>
              <span>05</span> The main component of a healthy env for
              self esteem.
            </li>
          </ul>

          <div class="quotes text-center">
            <p>
              Never ever think of giving up. Winners never quit and
              quitters never win. Take all negative words out of your
              mental dictionary and focus on the solutions with utmost
              conviction and patience. The battle is never lost until
              you've abandon your vision.
            </p>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="mb-10">
                <img src="/img/blog/2.jpg" alt="" />
              </div>
            </div>
            <div class="col-md-6">
              <div class="mb-10">
                <img src="/img/blog/3.jpg" alt="" />
              </div>
            </div>
          </div>
          <p>
            We all intend to plan ahead, but too often let the
            day-to-day minutia get in the way of making a calendar for
            the year. Sure, you can't know every detail to anticipate.
            Heck, you can't know half the priorities that will pop up
            in any particular month. But you can plan for big picture
            seasonality, busy-times, and events.
          </p>
          <div class="share-info">
            <div class="social">
              <a href="#0">
                <i class="fab fa-facebook-f"></i>
              </a>
              <a href="#0">
                <i class="fab fa-twitter"></i>
              </a>
              <a href="#0">
                <i class="fab fa-behance"></i>
              </a>
            </div>
            <div class="tags">
              <a href="#0">Web</a>,<a href="#0">Themeforest</a>,
              <a href="#0">ThemesCamp</a>
            </div>
          </div>
        </div>
        <div class="author">
          <div class="author-img">
            <img src="/img/blog/01.jpg" alt="" />
          </div>
          <div class="info">
            <h6><span>author :</span> Jorden Griffin</h6>
            <p>
              the main component of a healthy environment for self
              esteem is that it needs be nurturing. The main compont
              of a healthy environment.
            </p>
            <div class="social">
              <a href="#0">
                <i class="fab fa-facebook-f"></i>
              </a>
              <a href="#0">
                <i class="fab fa-twitter"></i>
              </a>
              <a href="#0">
                <i class="fab fa-behance"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
