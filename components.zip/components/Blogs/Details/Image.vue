<template>
  <div class="img">
    <img src="/img/blog/single.jpg" alt="" />
  </div>
</template>
