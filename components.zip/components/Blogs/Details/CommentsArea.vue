<template>
  <div class="comments-area">
    <h5>Comments :</h5>
    <div class="item">
      <div class="comment-img">
        <img src="/img/blog/01.jpg" alt="" />
      </div>
      <div class="info">
        <h6>Jorden Griffin - <span> 6 Aug 2023</span></h6>
        <span class="replay">
          <a href="#0"> Replay <i class="fas fa-reply"></i> </a>
        </span>
        <p>
          the main component of a healthy environment for self esteem
          is that it needs be nurturing. The main compont of a healthy
          environment.
        </p>
      </div>
    </div>
    <div class="item relped">
      <div class="comment-img">
        <img src="/img/blog/01.jpg" alt="" />
      </div>
      <div class="info">
        <h6>Jorden Griffin - <span> 6 Aug 2023</span></h6>
        <span class="replay">
          <a href="#0"> Replay <i class="fas fa-reply"></i> </a>
        </span>
        <p>
          the main component of a healthy environment for self esteem
          is that it needs be nurturing. The main compont of a healthy
          environment.
        </p>
      </div>
    </div>
    <div class="item">
      <div class="comment-img">
        <img src="/img/blog/01.jpg" alt="" />
      </div>
      <div class="info">
        <h6>Jorden Griffin - <span> 6 Aug 2023</span></h6>
        <span class="replay">
          <a href="#0"> Replay <i class="fas fa-reply"></i> </a>
        </span>
        <p>
          the main component of a healthy environment for self esteem
          is that it needs be nurturing. The main compont of a healthy
          environment.
        </p>
      </div>
    </div>
  </div>
</template>
