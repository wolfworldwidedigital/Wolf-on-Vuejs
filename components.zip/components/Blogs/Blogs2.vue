<template>
  <section class="blog-list section-padding sub-bg">
    <div class="container">
      <div class="row">
        <div class="col-lg-4">
          <div class="head md-mb50">
            <h6 class="back-color">Get The Latest News</h6>
            <h3>What Our Trending News.</h3>
            <p>
              We provide company and finance service for startups and company
              business.
            </p>
            <NuxtLink to="#0">
              <span>More Blog Posts</span>
            </NuxtLink>
          </div>
        </div>
        <div class="col-lg-7 offset-lg-1">
          <div class="item wow fadeInUp" data-wow-delay=".3s">
            <div class="img valign">
              <img src="/img/blog/1.jpg" alt="" />
            </div>
            <div class="cont valign">
              <div>
                <div class="info">
                  <NuxtLink to="#0" class="date">
                    <span><i>06</i> August</span>
                  </NuxtLink>
                  <span>/</span>
                  <NuxtLink to="#0" class="tag">
                    <span>WordPress</span>
                  </NuxtLink>
                </div>
                <h5>
                  <NuxtLink to="#0">
                    How to use solid color combine with simple furnitures.
                  </NuxtLink>
                </h5>
              </div>
            </div>
          </div>
          <div class="item wow fadeInUp" data-wow-delay=".5s">
            <div class="img valign">
              <img src="/img/blog/2.jpg" alt="" />
            </div>
            <div class="cont valign">
              <div>
                <div class="info">
                  <NuxtLink to="#0" class="date">
                    <span><i>06</i> August</span>
                  </NuxtLink>
                  <span>/</span>
                  <NuxtLink to="#0" class="tag">
                    <span>WordPress</span>
                  </NuxtLink>
                </div>
                <h5>
                  <NuxtLink to="#0">
                    How to use solid color combine with simple furnitures.
                  </NuxtLink>
                </h5>
              </div>
            </div>
          </div>
          <div class="item wow fadeInUp" data-wow-delay=".3s">
            <div class="img valign">
              <img src="/img/blog/3.jpg" alt="" />
            </div>
            <div class="cont valign">
              <div>
                <div class="info">
                  <NuxtLink to="#0" class="date">
                    <span><i>06</i> August</span>
                  </NuxtLink>
                  <span>/</span>
                  <NuxtLink to="#0" class="tag">
                    <span>WordPress</span>
                  </NuxtLink>
                </div>
                <h5>
                  <NuxtLink to="#0">
                    How to use solid color combine with simple furnitures.
                  </NuxtLink>
                </h5>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>