<template>
  <header class="particles circle-bg valign">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-10">
          <div class="cont text-center">
            <h1>
              <span class="color-font">Creativity</span> is the process of
              having <span class="color-font">original ideas</span>.
            </h1>
          </div>
        </div>
      </div>
    </div>
    <div class="gradient-circle"></div>
    <div class="gradient-circle two"></div>
    <div class="line bottom left"></div>
  </header>
</template>

<script setup>
const { theme } = defineProps(['theme']);
</script>
