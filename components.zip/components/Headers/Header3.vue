<template>
  <header class="slider-stwo valign position-re">
    <div class="container">
      <div class="row">
        <div class="col-lg-5">
          <div class="img">
            <img src="/img/slid/002.jpg" alt="" />
          </div>
        </div>
        <div class="col-lg-7 valign">
          <div class="cont">
            <div class="sub-title mb-5">
              <h6>Digital Consulting Agency</h6>
            </div>
            <h1 class="mb-10 fw-600">Unique Business Consulting.</h1>
            <p>
              We help our clients succeed by creating brand identities,
              <br />
              digital experiences, and print materials.
            </p>
            <ul>
              <li>
                <div>
                  <span class="icon pe-7s-arc">
                    <div class="bord"></div>
                  </span>
                </div>
                <div class="cont">
                  <h6>Branding</h6>
                  <p>
                    It is a long established fact that a reader will be
                    distracted.
                  </p>
                </div>
              </li>
              <li>
                <div>
                  <span class="icon pe-7s-help2">
                    <div class="bord"></div>
                  </span>
                </div>
                <div class="cont">
                  <h6>Marketing</h6>
                  <p>
                    It is a long established fact that a reader will be
                    distracted.
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </header>
</template>