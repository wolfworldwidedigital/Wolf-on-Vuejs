<template>
  <header class="slider-st valign position-re">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 valign">
          <div class="cont md-mb50">
            <div class="sub-title mb-5">
              <h6>Digital Consulting Agency</h6>
            </div>
            <h1 class="mb-10 fw-600">Unique Business Consulting.</h1>
            <p>
              We help our clients succeed by creating brand identities, digital
              experiences, and print materials.
            </p>
            <NuxtLink class="butn bord curve mt-30" to="/about/about-dark">
              <span>About Us</span>
            </NuxtLink>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="img">
            <img src="/img/slid/001.jpg" alt="" />
          </div>
        </div>
      </div>
    </div>
    <div class="line bottom left"></div>
  </header>
</template>